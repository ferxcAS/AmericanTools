<?php
require_once "functions.php";

stopAttack();

header('location: index.php');

?>