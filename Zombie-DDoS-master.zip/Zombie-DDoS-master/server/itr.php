<?php
require_once "functions.php";

echo getIterValue();

?>